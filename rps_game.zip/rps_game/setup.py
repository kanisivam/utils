from setuptools import setup
setup(
    name='RPS',
    version='1.1.0',
    description='Rock Paper Scissors',
    packages=['rps_game'],
    include_package_data=True,
    entry_points={
    },
)
